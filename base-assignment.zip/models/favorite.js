

// TODO: Create the Favorite model using Mongoose