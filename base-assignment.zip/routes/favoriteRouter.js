
// TODO: Implement the favoriteRouter using the Express Router